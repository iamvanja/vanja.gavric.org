var express = require("express"),
	app = express(),
	port = 2000;

app.configure(function(){

	app.use(express.favicon());
	app.use(express.logger("dev"));

	app.use(express.bodyParser());
	app.use(express.cookieParser());
	app.use(express.methodOverride());


	app.use(express["static"]("public"));

});


app.configure("development", function() {
    app.use(express.errorHandler({
        dumpException: true,
        showStack: true
    }));
});

app.listen(port);
console.log("App listening on port: " + port);

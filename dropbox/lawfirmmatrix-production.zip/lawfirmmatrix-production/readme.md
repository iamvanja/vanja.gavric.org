lawfirm client app
==============================================================



Installing the app
------------------

### Prerequisites ###

In order to run and build the application you must install:

	node.js: for instructions on installing node.js go to http://nodejs.org/
	npm: Npm is the package manager for node, to install it go to https://npmjs.org/, but it usualy comes bundled with node.js


### Installing dependencies ###

After cloning the repository go to the root directory of the repo and execute:

        >npm install

you shouldn't have any problem running this command, 
but if some module fail to install you might need to install it globally
to do that just run:  

        >npm install -g [module_name]

this will require admin privileges to install

### Installing Build environment ###

[Grunt.js](http://gruntjs.com/getting-started) is the build tool, it should be installed as a dependency, but you also need a cli (command line interface) to run it

to install the cli simply run:

       >npm install -g grunt-cli



Building the App
-----------------

To build the project simply run:

       >grunt

it should perform a serie of automated task as:

Cleaning the build directories

* public/js/

running jshint over the js files

precompiling the templates files for player and moderator app
converting all the html files in [app]/templates/*.html
to /build/templates.js


copy the files from /src/client/[app]/ to /public/js/[app]/


run the test with mocha.js i phantom.js

compile .less style files into a .css file in /public/css/[app].css

minifies the .css file to /public/css/[app].min.css



Running the dev server
----------------------

to run the dev server, go to the root directory and run:

        >node server

it will run a http server on port 5000 by default

module.exports = function(grunt) {

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON("package.json"),
    jshint: {
        options: {
            curly: true,
            eqeqeq: true,
            immed: true,
            latedef: true,
            newcap: true,
            noarg: true,
            sub: true,
            undef: true,
            boss: true,
            eqnull: true,
            browser: true,
            plusplus: false,
            smarttabs: true,
            scripturl: true,
            evil: true,
            globals: {
                global: true,
                process: true,
                console: true,
                Buffer: true,
                require: true,
                __filename: true,
                __dirname: true,
                module: true,
                exports:true,
                //for Browser
                Backbone: true,
                _: true,
                window: true,
                alert: true,
                $: true,
                jQuery: true,
                ace: true,
                d3: true,
                define: true, 
                requirejs: true,
                JsSHA: true
            }
        },
        files: {
            src: [
              "Gruntfile.js",
              "server.js",
              "src/client/spa/**/*.js",
              "test/client/**/.*.js"
            ]
        }
    },
    clean: {
        apps: [
            "public/js/spa", 
            "build"
        ],
        build: [
            "build"
        ]
    },
    copy: {
        spa: {
            files: [
                {
                    expand: true,
                    cwd: "src/client/spa/", 
                    src: ["**/*.js"], 
                    dest: "public/js/spa/"
                },
                {
                    expand: true,
                    cwd: "build/", 
                    src: ["**/*.js"], 
                    dest: "public/js/spa/"
                }
            ]
        }
    },
    concat: {
        bootstrap: {
            src: [
                "src/client/styles/bootstrap/js/bootstrap-affix.js",
                "src/client/styles/bootstrap/js/bootstrap-alert.js",
                "src/client/styles/bootstrap/js/bootstrap-button.js",
                "src/client/styles/bootstrap/js/bootstrap-carousel.js",
                "src/client/styles/bootstrap/js/bootstrap-collapse.js",
                "src/client/styles/bootstrap/js/bootstrap-dropdown.js",
                "src/client/styles/bootstrap/js/bootstrap-modal.js",
                "src/client/styles/bootstrap/js/bootstrap-tooltip.js",
                "src/client/styles/bootstrap/js/bootstrap-popover.js",
                "src/client/styles/bootstrap/js/bootstrap-scrollspy.js",
                "src/client/styles/bootstrap/js/bootstrap-tab.js",
                "src/client/styles/bootstrap/js/bootstrap-transition.js",
                "src/client/styles/bootstrap/js/bootstrap-typeahead.js"
            ],
            dest: "public/js/vendor/bootstrap.js"
        }
    },
    uglify: {
        bootstrap: {
            files: {
                "public/js/vendor/bootstrap.min.js": ["public/js/vendor/bootstrap.js"]
            }
        }
    },
    jst: {
        spa:{
            options:{
                prettify: true,
                processName: function(longPath){
                    return longPath.substr(25);
                }
            },
            files:{
                "build/templates.js": [
                    "src/client/spa/templates/**/*.html"
                ]
            }
        }
    },
    less: {
        bootstrap: {
            files: {
                "public/css/bootstrap.css": "src/client/styles/bootstrap/less/bootstrap.less"
            }
        },
        spa: {
            files:{
                "public/css/spa.css": "src/client/spa/style/main.less"
            }
        }
    },
    cssmin: {
        compress: {
            files: {
               "public/css/bootstrap.min.css": ["public/css/vendor/bootstrap.css"]
            }
        },
        spa: {
            files: {
                "public/css/spa.min.css": ["public/css/spa.css"]
            }
        }
    },
    watch: {
        scripts: {
            files: [
                "src/client/spa/**/*"
            ],
            tasks: [
                "default"
            ],
            options: {
                spawn: false,
                debounceDelay: 250
            }
        }
    },
    mocha: {
      // Runs 'test/test2.html' with specified mocha options.
      // This variant auto-includes 'bridge.js' so you do not have
      // to include it in your HTML spec file. Instead, you must add an
      // environment check before you run `mocha.run` in your HTML.
      test: {
        // Test files
        src: [ 'test/client/mocha.html' ],
        options: {
          // Bail means if a test fails, grunt will abort. False by default.
          bail: true,

          // Pipe output console.log from your JS to grunt. False by default.
          log: true,

          // mocha options
          mocha: {
            ignoreLeaks: false
          },

          // Select a Mocha reporter
          // http://visionmedia.github.com/mocha/#reporters
          reporter: 'Nyan',

          // Indicates whether 'mocha.run()' should be executed in
          // 'bridge.js'. If you include `mocha.run()` in your html spec,
          // check if environment is PhantomJS. See example/test/test2.html
          run: false,

          // Override the timeout of the test (default is 5000)
          timeout: 10000
        }
      }
    }

  });

  grunt.loadNpmTasks("grunt-contrib-jshint");
  grunt.loadNpmTasks("grunt-contrib-concat");
  grunt.loadNpmTasks("grunt-contrib-uglify");
  grunt.loadNpmTasks("grunt-contrib-less");
  grunt.loadNpmTasks("grunt-contrib-cssmin");
  grunt.loadNpmTasks("grunt-contrib-jst");
  grunt.loadNpmTasks("grunt-contrib-copy");
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-mocha');    

  // Default task(s).
  grunt.registerTask(
    "default", 
    [
        "clean:apps", 
        "jshint", 
        "jst:spa", 
        "copy:spa", 
        "clean:build", 
        "mocha:test",
        "less:spa",
        "cssmin:spa"
    ]);

};
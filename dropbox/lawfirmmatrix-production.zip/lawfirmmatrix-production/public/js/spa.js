requirejs.config({
  deps: ["spa/main"],
  paths: {
  },

  shim: {
  }
});
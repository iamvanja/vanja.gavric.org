define([
	"spa/templates",
	"spa/TopBar",
	"spa/Menu",
	"spa/Breadcrumbs",
	"spa/Components",
	"spa/Screens"
	], 
	function(t, TopBar, Menu, Breadcrumbs, Components, Screens){
	var AppLayout = Backbone.Marionette.Layout.extend({
		initialize: function(){
			var that = this;
			this.sm = this.options.sm;
			this.app = this.options.app;
			this.sm.on("menu", function(){
				that.showMenu();
			});
		},
		template: function(){
			return window.JST["appLayout.html"];
		},
		regions: {
			header: "#header",
			menu: "#menu",
			breadcrumbs: "#breadcrumbs",
			content: "#content"
		},
		showMenu: function(){
			this.menu.show(new Menu({
				menu: this.sm.menu,
				delegate: this
			}));
		},
		onShow: function(){
			this.header.show(new TopBar());
			//this.breadcrumbs.show(new Breadcrumbs());
			//this.showMenu();
			this.scrMngr = new Screens.ScreensManager();

			var widget = new Components.Widget({
					model: new Backbone.Model({
						title: "Add a customer"
					})
				});

			this.content.show(new Components.Tabs({
				delegate: this,
				tabs: this.sm.tabs
			}));
		},
		load: function(screen){
			console.log("Loading Screen " + screen.type + " from : " + screen.api);
		}
	});
	return AppLayout;
});
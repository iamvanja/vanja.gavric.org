define([
	"spa/screens/ScreensManager"
	], 
	function(ScrMngr){
	
	return {
		ScreensManager: ScrMngr
	};
});
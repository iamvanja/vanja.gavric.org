define([
	"spa/SessionManager",
	"spa/LoginLayout",
	"spa/AppLayout"
	], 
	function(SessionManager, LoginLayout, AppLayout){
	var App = Backbone.Marionette.Application.extend({
		init: function(){
			var that = this;

			this.sm = new SessionManager();
			this.mainRegion.show(new LoginLayout({
				sessionManager: this.sm
			}));

			this.sm.on("loggedIn", function(){
				that.mainRegion.show(new AppLayout({
					sm: that.sm,
					app: that
				}));
			});

			//UNCOMMENT THIS LINE TO AVOID LOGIN SCREEN
			//this.sm.login("yhalberstam","mgr4");
			window.app = this;
		}
	});
	return App;
});
define([
	"spa/templates"
	], 
	function(t){
	var MenuOptionItem = Backbone.Marionette.ItemView.extend({
		tagName: "li",
		className: "js-menuOptionItem",
		initialize: function(){
			this.delegate = this.options.delegate;
			this.parent = this.options.parent;
			this.parent.items.push(this);
		},
		template: function(serialized){
			return window.JST["menuOptionItem.html"](serialized);
		},
		events: {
			"click a": "load"
		},
		load: function(){
			this.select();
			this.delegate.load(this.model.toJSON());
		},
		select: function(){
			this.parent.deselectAllItems();
			this.parent.select();
			this.$el.addClass("active");
		},
		deselect: function(){
			this.$el.removeClass("active");
		}
	});
	return MenuOptionItem;
});
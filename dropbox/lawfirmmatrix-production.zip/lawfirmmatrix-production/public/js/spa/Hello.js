define([
	"spa/templates"
	],
	function(templates){
		var Hello = Backbone.Marionette.ItemView.extend({
			template: function(serializedModel){
				return window.JST["hello.html"](serializedModel);
			},
			name: function(){
				return this.model.get("name");
			}
		});
		return Hello;
	});
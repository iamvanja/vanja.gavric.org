define([
	"spa/templates",
	"spa/MenuOption"
	], 
	function(t, MenuOption){
	var Menu = Backbone.Marionette.CompositeView.extend({
		initialize: function(){
			this.collection = new Backbone.Collection(this.options.menu.options);
			this.delegate = this.options.delegate;
			this.opts = [];
		},
		template: function(){
			return window.JST["menu.html"];
		},
		itemView: MenuOption,
		itemViewContainer: ".js-menuItems",
		itemViewOptions: function () {
			return {
				delegate: this.delegate,
				parent: this
			};
		},
		onShow: function(){
			ace.handle_side_menu(jQuery);
		},
		deselectAllOptions: function(){
			var arr = this.opts,
				l = arr.length,
				i;
			for(i = 0; i < l; i += 1){
				arr[i].deselect();
			}
		}
	});
	return Menu;
});
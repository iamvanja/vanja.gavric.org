define([
	"spa/templates"
	], 
	function(){
	var Breadcrumbs = Backbone.Marionette.ItemView.extend({
		template: function(){
			return window.JST["breadcrumbs.html"];
		}
	});
	return Breadcrumbs;
});
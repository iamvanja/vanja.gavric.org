define([
	"spa/screens/Screen",
	"spa/screens/List",
	"spa/screens/newEntity"
	],
	function(Screen, List, NewEntity){
		var ScrMngr = function(){
			return {
				load: function(screen){
					var scr;
					switch(screen.type){
						case "list":
							scr = new List(screen);
							break;
						case "newEntity":
							scr = new NewEntity(screen);
							break;
						default:
							scr = new Screen();
					}
					return scr;
				}
			};
		};

		return ScrMngr;
	});
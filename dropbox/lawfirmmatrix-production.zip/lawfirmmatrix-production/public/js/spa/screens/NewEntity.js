define([
	"spa/templates",
	"spa/Components"
	],
	function(t, Components){
		var Screen = Backbone.Marionette.Layout.extend({
			template: function(){
				return window.JST["screens/screen.html"];
			},
			initialize: function(){
				/*$.ajax({
					url: this.options.api,
					method: "GET"
				});*/
			},
			regions: {
				breadcrumbs: ".breadcrumbs",
				content: ".content"
			},
			onShow: function(){
				this.content.show(new Components.Form({
					model: new Backbone.Model({
						steps: [
							{
								name: 1,
								title: "Basic Info",
								collapsed: false,
								fields: [
									{placeholder: "Full legal name", label: "Enter the customer's full legal name.", type: "text", value: ""},
									{placeholder: "Email", label: "Enter the customer's email.", type: "text", value: ""}
								]
							},
							{
								name: 2,
								title: "Basic Info",
								collapsed: false,
								fields: [
									{placeholder: "Business name", label: "Enter the full business name.", type: "text", value: ""},
									{placeholder: "EIN number", label: "Enter the EIN number.", type: "text", value: ""},
									{placeholder: "Name", label: "Enter the business representative's full legal name.", type: "text", value: ""},
									{placeholder: "Email", label: "Enter the email.", type: "text", value: ""}
								]
							},
							{
								name: 3,
								title: "Additional Info",
								collapsed: true,
								fields: [
									{ placeholder: "Permanent street address (line 1)", label: "Enter the permanent street address.", type: "text", value: ""},
									{ placeholder: "Permanent street address (line 2)", label: "Enter the permanent street address.", type: "text", value: ""},
									{ placeholder: "City", label: "Enter the city.", type: "text", value: ""},
									{ placeholder: "Country", label: "Enter the country.", type: "text", value: ""},
									{ placeholder: "State/Province", label: "Enter the state or province.", type: "text", value: ""},
									{ placeholder: "Postal code", label: "Enter the postal code.", type: "text", value: ""},
									{ placeholder: "Phone number", label: "Enter the phone number.", type: "phone", value: ""},
									{ placeholder: "Date of birth", label: "Enter the date of birth.", type: "date", value: ""},
									{ placeholder: "Last 4 of SSN", label: "Enter the last 4 digits of the social security number.", type: "text", value: "", mask: "9999"},
									{ placeholder: "Facebook ID", label: "Enter the Facebook ID.", type: "text", value: ""},
									{ placeholder: "Twitter ID", label: "Enter the Twitter ID.", type: "text", value: ""}
								]
							}
						]
					})
				}));
			}
		});
		return Screen;
	});
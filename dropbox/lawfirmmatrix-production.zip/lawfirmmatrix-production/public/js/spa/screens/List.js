define([
	"spa/templates",
	"spa/Components"
	],
	function(t, Components){
		var Screen = Backbone.Marionette.Layout.extend({
			template: function(){
				return window.JST["screens/screen.html"];
			},
			initialize: function(){
				/*$.ajax({
					url: this.options.api,
					method: "GET"
				});*/
			},
			regions: {
				breadcrumbs: ".breadcrumbs",
				content: ".content"
			},
			onShow: function(){
				this.content.show(new Components.List({
				schema: {
					fields: [
						{
							title: "Client name",
							name: "clientName",
							type: "ImageAndText"
						},
						{
							title: "Last activity",
							name: "lastActivity",
							type: "Text"
						},
						{
							title: "Client Type",
							name: "clientType",
							type: "Tag"
						},
						{
							title: "Status",
							name: "status",
							type: "Tag"
						},
						{
							title: "Account Manager",
							name: "accountManager",
							type: "Text"
						},
						{
							title: "Total time",
							name: "totalTime",
							type: "Number"
						},
						{
							title: "Total Escrow",
							name: "totalEscrow",
							type: "Money"
						}
					]
				},
				data: [
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Jessie Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/08/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Prospects"
							},
							{
								type: "accountManager",
								value: "Soul Jackson"
							},
							{
								type: "totalTime",
								value: "87"
							},
							{
								type: "totalEscrow",
								value: "32444"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Soul White",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/09/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Project"
							},
							{
								type: "accountManager",
								value: "Jessie Smith"
							},
							{
								type: "totalTime",
								value: "59.5"
							},
							{
								type: "totalEscrow",
								value: "10664.12"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Sally Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/10/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Active"
							},
							{
								type: "accountManager",
								value: "Sally Rodrigez"
							},
							{
								type: "totalTime",
								value: "55"
							},
							{
								type: "totalEscrow",
								value: "11270.10"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Michael Rodrigez",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/11/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Leads"
							},
							{
								type: "accountManager",
								value: "Ralph Goodman"
							},
							{
								type: "totalTime",
								value: "56"
							},
							{
								type: "totalEscrow",
								value: "16554.46"
							}
						]
					},
					{
						row: [
							{
								type: "clientName",
								value: "Ralph Pinkman",
								url: "https://qa.lawfirmmatrix.com/Content/assets/avatars/user.jpg"
							},
							{
								type: "lastActivity",
								value: "11/12/2013"
							},
							{
								type: "clientType",
								value: "Individual"
							},
							{
								type: "status",
								value: "Pending Approval"
							},
							{
								type: "accountManager",
								value: "John Jackson"
							},
							{
								type: "totalTime",
								value: "52"
							},
							{
								type: "totalEscrow",
								value: "9054.91"
							}
						]
					}
					
				]
			}));
			}
		});
		return Screen;
	});
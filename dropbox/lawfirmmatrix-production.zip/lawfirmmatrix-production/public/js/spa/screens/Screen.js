define([
	"spa/templates"
	],
	function(t){
		var Screen = Backbone.Marionette.Layout.extend({
			template: function(){
				return window.JST["screens/screen.html"];
			},
			initialize: function(){
				/*$.ajax({
					url: this.options.api,
					method: "GET"
				});*/
			},
			regions: {
				breadcrumbs: ".breadcrumbs",
				content: ".content"
			},
			onShow: function(){
				this.content.show(new Backbone.Marionette.ItemView({
					template: "<h1>"+ this.options.title +" <br/>ScreenType: " + this.options.type +" (api:" + this.options.api + ")</h1>"
				}));
			}
		});
		return Screen;
	});
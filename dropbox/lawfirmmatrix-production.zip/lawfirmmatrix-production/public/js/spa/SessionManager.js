define([
	],
	function(){
		var SessionManager = function(){
			return _.extend({
				loggedIn: false,
				parse: function(resp){
					if(resp.response === "success"){
						this.loggedIn = true;
						this.tabs = resp.session.tabs.opened;
						this.trigger("loggedIn");
						this.trigger("change", true);
					}

					if(resp.response === "fail"){
						if(this.loggedIn){
							this.trigger("change", false);
						}
						this.trigger("loginFail");
						this.loggedIn = false;
					}
				},
				parseMenu: function(res){
					this.menu = res;
					this.trigger("menu");
				},
				login: function(username, password){
					var that = this;
					/*$.ajax({
						url: "/api/login",
						method: "POST",
						data: {
							username: username,
							password: password
						},
						success: function(res){
							that.parse(res);
						}
					});*/
					if((username === "yhalberstam") && (password === "mgr4")){
						this.parse({
							response: "success",
							user: {
								fullname: "Yossi Halberstam",
								userId: "01",
								profilePhoto: "img/user.jpg"
							},
							company: {
								name: "LawFirm Matrix",
								logo: "img/KLF-logo.png"
							},
							session:{
								tabs: {
									current: 0,
									opened: [
										{
											title: "Client List",
											active: true,
											type: "list",
											api: "/api/scheme/clients"
										},
										{
											title: "New Client",
											active: false,
											type: "newEntity",
											api: "/api/scheme/newClient"
										}
									]
								}
							}
						});
						this.parseMenu({
							options:[
								{
									menu: "Kaiser Law Firm",
									icon: "icon-building",
									options:[
										{
											name: "Dashboard",
											type: "report",
											api: "/api/scheme/dashboard"
										},
										{
											name: "Employees",
											type: "list",
											api: "/api/scheme/employees"
										},
										{
											name: "Vendors",
											type: "list",
											api: "/api/scheme/vendors"
										}
									]
								},
								{
									menu: "Work",
									icon: "icon-bar-chart",
									options:[
										{
											name: "Projects",
											type: "list",
											api: "/api/scheme/projects"
										},
										{
											name: "Clients",
											type: "list",
											api: "/api/scheme/clients"
										},
										{
											name: "Time & Expenses",
											type: "list",
											api: "/api/scheme/timeAndExpenses"
										},
										{
											name: "Invoices",
											type: "list",
											api: "/api/scheme/invoices"
										}
									]
								},
								{
									menu: "Money",
									icon: "icon-money",
									options:[
										{
											name: "Money In / Money Out",
											type: "list",
											api: "/api/scheme/moneyInMoneyOut"
										},
										{
											name: "Payments Processing",
											type: "list",
											api: "/api/scheme/paymentProcessing"
										},
										{
											name: "Bill Pay",
											type: "list",
											api: "/api/scheme/billPay"
										},
										{
											name: "Bank Accounts",
											type: "list",
											api: "/api/scheme/bankAccounts"
										}
									]
								},
								{
									menu: "Reporting",
									icon: "glyphicon glyphicon-folder-open",
									options:[
										{
											name: "Reports",
											type: "list",
											api: "/api/scheme/reports"
										},
										{
											name: "Analytics",
											type: "list",
											api: "/api/scheme/analytics"
										}
									]
								},
								{
									menu: "Bussiness Tools",
									icon: "glyphicon glyphicon-briefcase",
									options:[
										{
											name: "Alerts",
											type: "list",
											api: "/api/scheme/alerts"
										},
										{
											name: "Emails",
											type: "list",
											api: "/api/scheme/emails"
										},
										{
											name: "Calendar",
											type: "list",
											api: "/api/scheme/calendar"
										},
										{
											name: "Contacts",
											type: "list",
											api: "/api/scheme/contats"
										},
										{
											name: "Tasks",
											type: "list",
											api: "/api/scheme/tasks"
										}
									]
								}
							]
						});
					}else{
						this.parse({
							response: "fail"
						});
					}
				},
				logout: function(){
					this.loggedIn = false;
					this.trigger("logout");
					/*$.ajax({
						url: "/api/logout",
						method: "GET"
					});*/
				}
			}, Backbone.Events);
		};

		return SessionManager;
	});
define([
	"spa/templates",
	"spa/components/FormField"
	], 
	function(t, FormField){
	var FormSection = Backbone.Marionette.CompositeView.extend({
		initialize: function(){
			var fields = this.model.get("fields");
			this.collection = new Backbone.Collection(fields);
		},
		template: function(serialized){
			console.log(serialized);
			return window.JST["components/formSection.html"](serialized);
		},
		itemViewContainer: "form",
		itemView: FormField,
		onShow: function() {
			console.log('on show form section!');
			var collapsed = this.model.get('collapsed');
			if (!collapsed) {
				this.$el.find('.accordion-toggle').click();
			}
		}
	});
	return FormSection;
});
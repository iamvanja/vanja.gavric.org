define([
	"spa/templates",
	"spa/components/listParser"
	// "spa/components/ListHeaders",
	// "spa/components/ListContent"
	],
	function(t, ListParser){
	var List = Backbone.Marionette.Layout.extend({
		initialize: function(){
			// this.HeaderCollection = new Backbone.Collection(this.options.schema.fields);
			// this.ContentCollection = new Backbone.Collection(this.options.data);
			this.listParser = new ListParser({
				header: this.options.schema.fields,
				content: this.options.data
			});
		},
		template: function(serialized){
			return window.JST["components/listLayout.html"](serialized);
		},
		regions: {
			filters: "#filters",
			listLayout: ".listLayout"
		},
		onShow: function(){
			// this.listLayout.show( new ListHeaders({
			// 	collection: this.HeaderCollection
			// }) );
			// this.listLayout.append( new ListContent({
			// 	collection: this.ContentCollection,
			// 	fieldTypes: this.HeaderCollection
			// }) );


			var that = this;
			this.dataTable = $(this.listLayout.el).dataTable({
				"aoColumns": this.listParser.parseHeader(),
				"aaData": this.listParser.parseContent(),
				"aLengthMenu": [
					[10, 20, 50, 100, -1],
					[10, 20, 50, 100, "All"]
				],
				"sPaginationType": "bs_normal",
				// "sDom": 'CT<"clear">lfrtip',
				// "sDom": '<"activity-bar"CT><"clear"><"filter-bar"lf>rtip',
				"sDom": '<"activity-bar"<"fr"T>><"workflow-bar"><"clear"><"filter-bar"l<"fr"Cf>>rtip',
				// "oColVis": {
				// 	"activate": "mouseover"
				// },
				"sScrollY": that.calcDataTableHeight(),
				// "bScrollCollapse": true,
				"oColVis": {
					"buttonText": "<i class=\"icon-ok\"></i>Select columns"
				},
				"oTableTools": {
					"sSwfPath": "css/vendor/datatables/copy_csv_xls_pdf.swf",
					"aButtons": [
						{
							"sExtends":    "collection",
							"sButtonText": 'Save <span class="caret" />',
							"aButtons":    [ "csv", "xls", "pdf" ]
						},
						"copy"
					]
				},
				"fnInitComplete" : function() {
					// $('.workflow-bar').addClass('boom');
					$('.dataTables_filter input').attr({placeholder: 'Search'})
						.addClass('input-sm')
						.wrap('<span class="input-icon" />')
						.parent().append('<i class="icon-search nav-search-icon" />');
					$('.activity-bar .fr').append('<button class="btn btn-sm btn-success"> <i class="icon-plus-sign"></i> Add New Client</button>');
				}
			});

			// workaround for now instead of doing it directly in fnInitComplete
			setTimeout(function(){
				that.initStatusFilters(3);
				that.initEditableTable();
			}, 100);
		

			// $(window).on('resize', function () {
			// 	// console.log('resize!');
			// 	var oSettings = that.dataTable.fnSettings();
			// 	console.log(oSettings);
			// 	// oSettings.sScrollY = that.calcDataTableHeight();
			// 	oSettings.oScroll.sY = '100';
			// 	oSettings.sScrollY = '100';
			// 	// that.dataTable.fnClearTable();
			// 	that.dataTable.fnDraw(false);
			// 	// that.dataTable.fnAdjustColumnSizing();
			// });

		},

		calcDataTableHeight: function() {
			return $(window).height()*45/100;
		},

		filterByColumn: function( val, column ){
			this.dataTable.fnFilter( val, column );
		},

		getUniqueRowData:function(iColumn){
			var that = this,
				oSettings = this.dataTable.fnSettings(),
				bUnique = true,
				bFiltered = true,
				bIgnoreEmpty = true,
				aiRows = oSettings.aiDisplay;
		
			// set up data array   
			var asResultData = [];
			
			for (var i=0, c = aiRows.length; i < c; i++) {
				var iRow = aiRows[i],
					aData = that.dataTable.fnGetData(iRow),
					sValue = $(aData[iColumn]).text();

				// ignore empty values?
				if (bIgnoreEmpty === true && sValue.length === 0) {
					continue;
				}
				// ignore unique values?
				else if (bUnique === true && jQuery.inArray(sValue, asResultData) > -1) {
					continue;
				}
				// else push the value onto the result data array
				else {
					asResultData.push( sValue );
				}
			}
			 
			return asResultData;
		},

		initStatusFilters: function( col ) {
			// FILTERS
			// prepend to filters All Clients
			var that = this,
				filters = that.getUniqueRowData( col ),
				filterHTML = '<div class="all col-xs-2"><button style="width:100%" class="btn btn-sm btn-primary" data-filter="">Show All</button></div><div class="col-xs-10"><div style="width:100%" class="btn-group">',
				templateFilter = function( val ){
					return "<button class=\"btn btn-sm\" data-filter=\""+ val +"\">"+ val +"</button>";
				},
				activeIndex = filters.indexOf('Active'),
				lastIndex = filters.length - 1;

				if (activeIndex !== -1) {
					// Make sure Active is last
					filters[activeIndex] = filters[lastIndex];
					filters[lastIndex] = 'Active';
				}

			_.each(filters, function(element, index, list) {
				filterHTML += templateFilter(element);
			});

			filterHTML += '</div></div>';

			$('.workflow-bar').append( filterHTML );
			$('.workflow-bar').find('button').on('click', function(){
				that.filterByColumn($(this).attr('data-filter'), 3);
				$('.workflow-bar button').removeClass('btn-primary');
				$(this).addClass('btn-primary').siblings().removeClass('btn-primary');
			});
		},

		initEditableTable: function() {
			var that = this;
			this.dataTable.$('td').editable( '/custom/api', {
				callback: function( sValue, y ) {
					var aPos = that.dataTable.fnGetPosition( this );
					that.dataTable.fnUpdate( sValue, aPos[0], aPos[1] );
				},
				submitdata: function ( value, settings ) {
					return {
						"row_id": this.parentNode.getAttribute('id'),
						"column": that.dataTable.fnGetPosition( this )[2]
					};
				},
				"height": "14px",
				"width": "100%"
			});
		}
	});
	return List;
});
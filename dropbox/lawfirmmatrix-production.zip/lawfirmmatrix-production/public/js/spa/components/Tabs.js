define([
	"spa/templates",
	"spa/components/TabsHeaders",
	"spa/components/TabsContents"
	],
	function(t, TabsHeaders, TabsContents){
		var Layout = Backbone.Marionette.Layout.extend({
			className: "tabs",
			initialize: function(){
				this.tabs = new Backbone.Collection(this.options.tabs);
				this.delegate = this.options.delegate;
			},
			template: function(){
				return window.JST["components/tabs.html"];
			},
			regions: {
				headers: ".tabsHeaders",
				contents: ".tabsContents"
			},
			onShow: function(){
				this.headers.show(new TabsHeaders({
					collection: this.tabs,
					delegate: this.delegate
				}));
				
				this.contents.show(new TabsContents({
					collection: this.tabs,
					delegate: this.delegate.scrMngr
				}));
				
			}
		});
		return Layout;
	});
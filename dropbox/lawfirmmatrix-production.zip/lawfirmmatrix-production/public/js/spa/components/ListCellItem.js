define([
	"spa/templates",
	"spa/components/ListCellItemText",
	"spa/components/ListCellItemNumber",
	"spa/components/ListCellItemImageAndText",
	"spa/components/ListCellItemMoney",
	"spa/components/ListCellItemTag"
	],
	function(t, ListCellItemText, ListCellItemNumber, ListCellItemImageAndText, ListCellItemMoney, ListCellItemTag){
	var ListCellItem = Backbone.Marionette.Layout.extend({
		initialize: function() {
			this.fieldTypes = this.options.fieldTypes;
		},
		tagName: "td",
		className: "td123",
		regions: {
			cell: ".cell"
		},
		template: function(serialized) {
			return "<div class=\"cell\" />";
		},
		onShow: function(){
			var that = this,
				fieldType =this.fieldTypes.find(function(m){
					return m.get("name") === that.model.get("type");
				}),
				view;
			switch(fieldType.get("type")){
				case "ImageAndText":
					view = new ListCellItemImageAndText({
						model: this.model
					});
					break;
				case "Text":
					view = new ListCellItemText({
						model: this.model
					});
					break;
				case "Number":
					view = new ListCellItemNumber({
						model: this.model
					});
					break;
				case "Money":
					view = new ListCellItemMoney({
						model: this.model
					});
					break;
				case "Tag":
					view = new ListCellItemTag({
						model: this.model
					});
					break;
				default:
					view = new ListCellItemText({
						model: this.model
					});
					break;
			}
			this.cell.show(view);
			
		}

	});
	return ListCellItem;
});
define([
	"spa/templates"
	], 
	function(t, FormSection){
	var FormFieldText = Backbone.Marionette.ItemView.extend({
		initialize: function() {
			this.parent = this.options.parent;
		},
		ui: {
			input: "input"
		},
		events: {
			"keydown input": "keystroke",
			"focus input": "inputFocused",
			"blur input": "inputBlur"
		},
		template: function(serialized) {
			return window.JST["components/formField_text.html"](serialized);
		},
		onShow: function() {
			if (this.model.get('mask')) {
				var mask = this.model.get('mask');
				console.log('masking field...: ' + mask);
				this.ui.input.mask(mask);
			}
		},
		getVal: function() {
			return this.ui.input.val();
		},
		setVal: function(s) {
			return this.ui.input.val(s);
		},
		inputFocused: function(e) {
			this.parent.startEditing();
			this.ui.input.removeAttr('nosave');
			this.ui.input.select();
		},
		triggerBlur: function() {
			this.ui.input.blur();
		},
		inputBlur: function(e) {

			// 1. remove visual style of focus
			var self = this;
			self.parent.hideFocus();

			// 2. Delay (give time to any button event to abort the blur event)
			e.preventDefault(e);
			setTimeout(function() {
				if (self.ui.input.attr('nosave') === '1') {
					self.ui.input.removeAttr('nosave');
					return;
				}

				self.parent.save(false, function() {
					return true;
				});
			}, 300);
			
		},
		keystroke: function(e) {
			var self = this;
			var keyCode = e.keyCode || e.which; 

			if (keyCode === 13) { // enter
				self.ui.input.blur();
			}

			if (keyCode === 27) { // esc
				this.parent.cancelEditing();
			}
		},
		avoidSaving: function() {
			this.ui.input.attr('nosave', 1);
		}

	});
	return FormFieldText;
});
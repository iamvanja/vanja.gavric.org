define([
	"spa/templates",
	"spa/components/ListCellItem"
	],
	function(t, ListCellItem){
	var ListContentItem = Backbone.Marionette.CollectionView.extend({
		tagName: "tr",
		className: "tr123",
		initialize: function() {
			this.collection = new Backbone.Collection(this.model.get("row"));
			this.fieldTypes = this.options.fieldTypes;
		},
		itemView: ListCellItem,
		itemViewOptions: function(){
			return {
				fieldTypes: this.fieldTypes
			};
		}
	});
	return ListContentItem;
});
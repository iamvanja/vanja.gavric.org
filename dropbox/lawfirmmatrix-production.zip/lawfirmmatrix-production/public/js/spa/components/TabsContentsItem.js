define([
	"spa/templates"
	],
	function(t){
		var View = Backbone.Marionette.Layout.extend({
			className: "hide",
			initialize: function(){
				var that = this;
				this.delegate = this.options.delegate;
				this.model.on("change:active", function(){
					that.toggleActive();
				});
			},
			template: function(){
				return window.JST["components/tabsContentsItem.html"];
			},
			regions:{
				content: ".tabContent"
			},
			onShow: function(){
				if(this.model.get("active")){
					this.$el.removeClass("hide");
				}
				this.content.show(this.delegate.load(this.model.toJSON()));
			},
			toggleActive: function(){
				if (this.model.get("active")){
					this.$el.removeClass("hide");
				}else{
					this.$el.addClass("hide");
				}
			}
		});
		return View;
	});
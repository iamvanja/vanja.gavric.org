define([
	"spa/templates"
	],
	function(t){
		var View = Backbone.Marionette.ItemView.extend({
			tagName: "li",
			initialize: function(){
				var that = this;
				this.delegate = this.options.delegate;
				this.model.on("change:active", function(){
					that.toggleActive();
				});
			},
			events: {
				"click a": "select"
			},
			template: function(serialized){
				return window.JST["components/tabsHeadersItem.html"](serialized);
			},
			onShow: function(){
				if(this.model.get("active")){
					this.$el.addClass("active");
				}
			},
			toggleActive: function(){
				if (this.model.get("active")){
					this.$el.addClass("active");
				}else{
					this.$el.removeClass("active");
				}
			},
			select: function(){
				this.model.collection.each(function(m){
					m.set("active", false);
				});
				this.model.set("active", true);
			}
		});
		return View;
	});
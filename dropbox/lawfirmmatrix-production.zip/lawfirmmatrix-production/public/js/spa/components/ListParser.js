define([
	],
	function(){
		var ListParser = function(options){

			this.settings = _.extend({
				header: null,
				content: null
			}, options);
			var that = this;

			this._getValueByDataType = function(cell){
				var _getTemplateText = function(){
						return cell.value;
					},
					_getTemplateTag = function(){
						return "<span class=\"label arrowed\">"+ cell.value +"</span>";
					},
					_getTemplateImageAndText = function(){
						return "<img style=\"width: 2em; margin-right: 1em;\" alt=\"User's Photo\" src=\""+ cell.url +"\" class=\"img-circle\"><strong>"+ cell.value+ "</strong>";
					},
					_getTemplateMoney = function(){
						var num = isNaN(cell.value) || cell.value === '' || cell.value === null ? 0.00 : cell.value;
						return "$" + parseFloat(num).toFixed(2);
					},
					obj = _.find(this.settings.header, function(obj) {
						return obj.name === cell.type;
					}),
					value;

				switch (obj.type) {
					case 'Text':
					// deliberate fall-through
					case 'Number':
						value = _getTemplateText();
						break;
					case 'Tag':
						value = _getTemplateTag();
						break;
					case 'ImageAndText':
						value = _getTemplateImageAndText();
						break;
					case 'Money':
						value = _getTemplateMoney();
						break;
					default:
						value = _getTemplateText();
				}

				return value;
			};


			var	parseHeader = function() {
					var headerData = that.settings.header;
					if (headerData !== null) {
						_.each(headerData, function(headerItem){
							headerItem.sTitle = headerItem.title;
						});
						return headerData;
					}
					return false;
				},

				parseContent = function(){
					var contentData = that.settings.content,
						headerData = that.settings.header;
					if (contentData !== null) {
						var parsedContent = [],
							rowData = [];

						// loop over each row
						_.each(contentData, function(rowItem){
							// loop over each cell inside row
							_.each(rowItem.row, function(cellItem){
								// push to row generated cell
								rowData.push( that._getValueByDataType(cellItem) );
							});
							// push row into parsedContent
							parsedContent.push(rowData);

							// create a new, empty array for the new row
							rowData = [];
						});
						return parsedContent.length ? parsedContent : false;
					}
					return false;
				};


			return {
				parseHeader: parseHeader,
				parseContent: parseContent
			};
		};

		return ListParser;
	});
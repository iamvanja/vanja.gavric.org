define([
	"spa/templates"
	],
	function(t){
	var ListCellItemImageAndText = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return window.JST["components/listCellItemImageAndText.html"](serialized);
		}
		// tagName: "span"
	});
	return ListCellItemImageAndText;
});
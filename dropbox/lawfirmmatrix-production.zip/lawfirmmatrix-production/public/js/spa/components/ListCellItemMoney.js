define([
	"spa/templates"
	],
	function(t){
	var ListCellItemMoney = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return window.JST["components/listCellItemMoney.html"](serialized);
		},
		tagName: "span"
	});
	return ListCellItemMoney;
});
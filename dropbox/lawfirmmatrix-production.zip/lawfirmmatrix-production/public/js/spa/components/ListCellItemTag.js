define([
	"spa/templates"
	],
	function(t){
	var ListCellItemTag = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return window.JST["components/ListCellItemTag.html"](serialized);
		},
		tagName: "span",
		className: "label arrowed"
	});
	return ListCellItemTag;
});
define([
	"spa/templates"
	],
	function(t){
	var ListCellItemNumber = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return window.JST["components/listCellItemNumber.html"](serialized);
		}
	});
	return ListCellItemNumber;
});
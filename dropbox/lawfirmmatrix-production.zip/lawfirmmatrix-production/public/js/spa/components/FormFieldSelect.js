define([
	"spa/templates"
	], 
	function(t, FormSection){
	var FormFieldText = Backbone.Marionette.ItemView.extend({
		initialize: function() {
			this.parent = this.options.parent;
		},
		ui: {
			control: "select"
		},
		events: {
			"keydown select": "keystroke",
			"focus select": "inputFocused",
			"blur select": "inputBlur"
		},
		template: function(serialized) {
			return window.JST["components/formField_select.html"](serialized);
		},
		onShow: function(){
			console.log('initializing select2');
			console.log(this.ui.input);
			this.ui.control.select2();	
		},
		getVal: function() {
			return this.ui.control.val();
		},
		setVal: function(s) {
			return this.ui.control.val(s);
		},
		inputFocused: function(e) {
			this.parent.startEditing();
			this.ui.control.removeAttr('nosave');
			this.ui.control.select();
		},
		triggerBlur: function() {
			this.ui.control.blur();
		},
		inputBlur: function(e) {

			// 1. remove visual style of focus
			var self = this;
			self.parent.hideFocus();

			// 2. Delay (give time to any button event to abort the blur event)
			e.preventDefault(e);
			setTimeout(function() {
				if (self.ui.control.attr('nosave') === '1') {
					self.ui.control.removeAttr('nosave');
					return;
				}

				self.parent.save(false, function() {
					return true;
				});
			}, 300);
			
		},
		keystroke: function(e) {
			var self = this;
			var keyCode = e.keyCode || e.which; 

			if (keyCode === 13) { // enter
				self.ui.control.blur();
			}

			if (keyCode === 27) { // esc
				this.parent.cancelEditing();
			}
		},
		avoidSaving: function() {
			this.ui.control.attr('nosave', 1);
		}

	});
	return FormFieldText;
});
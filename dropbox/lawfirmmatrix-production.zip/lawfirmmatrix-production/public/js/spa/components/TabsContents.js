define([
	"spa/templates",
	"spa/components/TabsContentsItem"
	],
	function(t, TabsContentsItem){
		var View = Backbone.Marionette.CollectionView.extend({
			initialize: function(){
				this.delegate = this.options.delegate;
			},
			itemViewOptions: function(){
				return {
					delegate: this.delegate
				};
			},
			itemView: TabsContentsItem
		});
		return View;
	});
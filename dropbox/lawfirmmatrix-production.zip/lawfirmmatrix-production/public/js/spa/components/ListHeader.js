define([
	"spa/templates"
	],
	function(t){
	var ListHeader = Backbone.Marionette.ItemView.extend({
		tagName: "th",
		initialize: function() {
			console.log(this);
		},
		template: function(serialized) {
			return window.JST["components/listHeaderItem.html"](serialized);
		}
	});
	return ListHeader;
});
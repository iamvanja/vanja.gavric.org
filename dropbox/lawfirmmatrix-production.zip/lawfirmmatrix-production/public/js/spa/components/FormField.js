define([
	"spa/templates",
	"spa/components/FormFieldText",
	"spa/components/FormFieldMultiline",
	"spa/components/FormFieldDate",
	"spa/components/FormFieldSelect",
	"spa/components/FormFieldPhone"
	], 
	function(t, FormFieldText, FormFieldMultiline, FormFieldDate, FormFieldSelect, FormFieldPhone){
	var FormField = Backbone.Marionette.Layout.extend({
		template: function(serialized){
			return window.JST["components/newFormField.html"](serialized);
			// return window.JST["components/formField.html"](serialized);
		},
		ui: {
			btnEdit: "div.actions>div.edit",
			btnConfirm: "div.actions>div.confirm",
			btnCancel: "div.actions>div.cancel",
			btnUndo: "div.actions>div.undo",
			btnSaving: "div.actions>div.saving",
			valContainer: ".formValue"
			// btnAdd: "div.actions>div.add", 
		},
		regions: {
			control: ".formControl"
		},
		events: {
			"click div.actions > div.edit": "startEditing",
			"click div.actions > div.cancel": "cancelEditing",
			"click div.actions > div.undo": "undoChanges",
			"mouseenter .formValue": "fieldMouseEnter",
			"mouseleave .formValue": "fieldMouseLeave"
		},
		initialize: function() {
			switch(this.model.get("type")) {
				case "text":
					this.controlView = new FormFieldText({model: this.model, parent: this});
					break;

				case "multiline":
					this.controlView = new FormFieldMultiline({model: this.model, parent: this});
					break;

				case "date":
					this.controlView = new FormFieldDate({model: this.model, parent: this});
					break;

				case "select":
					this.controlView = new FormFieldSelect({model: this.model, parent: this});
					break;

				case "phone":
					this.controlView = new FormFieldPhone({model: this.model, parent: this});
					break;

				default:
					this.controlView = new FormFieldText({model: this.model, parent: this});
					break;
			}
		},
		onShow: function() {
			this.control.show(this.controlView);

			this.ui.btnEdit.find('button').attr('tabindex', '-1');
			this.ui.btnConfirm.find('button').attr('tabindex', '-1');
			this.ui.btnCancel.find('button').attr('tabindex', '-1');
			this.ui.btnUndo.find('button').attr('tabindex', '-1');
			this.ui.btnSaving.find('button').attr('tabindex', '-1');
		},
		undoChanges: function(e) {
			
			var prevVal = this.model.get("prevvalue");			
			console.log('Restoring: (prev: ' + prevVal + ') to replace [' + this.model.get("value") + ']');

			this.controlView.setVal(prevVal);
			this.model.set("value", prevVal);
			this.ui.btnUndo.hide();
			this.cancelEditing();
		},
		fieldMouseEnter: function(e) {
			this.ui.valContainer.addClass('valHover');
		},
		fieldMouseLeave: function(e) {
			this.ui.valContainer.removeClass('valHover');
		},
		startEditing: function() {
			this.ui.btnEdit.hide();
			this.ui.btnCancel.show();
			this.ui.btnConfirm.show();
			this.ui.valContainer.addClass('valFocused');
		},
		cancelEditing: function() {
			this.ui.btnEdit.show();
			this.ui.btnCancel.hide();
			this.ui.btnConfirm.hide();

			this.controlView.avoidSaving();
			this.controlView.setVal( this.model.get('value') );
		},
		hideFocus: function() {
			this.ui.valContainer.removeClass('valFocused');
			this.ui.valContainer.removeClass('valHover');
		},
		save: function(blurAfter, cb) {
			var that	= this;

			var prevVal = this.model.get("prevvalue"); //  || this.model.get("value");
			var newVal	= this.controlView.getVal();

			console.log('Saving: [' + newVal + '] (prev: ' + prevVal + ')');

			// this.model.set("prevvalue", prevVal);
			this.model.set("value", newVal);
			
			// this.ui.label.html(this.model.get("value")).show();
			this.ui.btnCancel.hide();
			this.ui.btnConfirm.hide();
			this.ui.btnSaving.show();
			if (blurAfter) {
				this.ui.controlView.triggerBlur();
			}
			setTimeout(function(){
				that.ui.btnSaving.hide();
				that.ui.btnEdit.show();

				if (newVal !== prevVal) {
					that.ui.btnUndo.show();
				}

				return cb();
			}, 200);
		}


	});
	return FormField;
});
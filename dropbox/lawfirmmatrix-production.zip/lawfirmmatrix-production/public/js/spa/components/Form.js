define([
	"spa/templates",
	"spa/components/FormSection"
	], 
	function(t, FormSection){
	var Form = Backbone.Marionette.CompositeView.extend({
		className: "wizard",
		useWizard: false,
		initialize: function(){
			this.collection = new Backbone.Collection(this.model.get("steps"));
		},
		template: function(serialized) {
			return window.JST["components/form.html"](serialized);
		},
		itemViewContainer: "#step-container",
		itemView: FormSection,
		onShow: function(){
			var self = this;
			console.log(this);

			// init top buttons
			var typeSel = self.$el.find('.form_type_selector');
			var formContainer = self.$el.find('#step-container');
			var submitContainer = self.$el.find('#submit-container');
			
			submitContainer.hide();
			formContainer.hide();
			typeSel.show();
			typeSel.find('.type-selector').click(function(ev) {
				ev.preventDefault();
				var myButton = $(ev.target);

				typeSel.find('.type-selector').removeClass('selected');
				myButton.addClass('selected');
				var targetSection = myButton.attr('data');
				var nonTargetSection = (targetSection === '#step1') ? '#step2' : '#step1';

				console.log('target / non target: ',targetSection,nonTargetSection);

				var targetSectionObj = $(targetSection);
				var nonTargetSectionObj = $(nonTargetSection);

				console.log(targetSectionObj);
				console.log(nonTargetSectionObj);

				targetSectionObj.show();
				nonTargetSectionObj.hide();

				formContainer.slideDown('fast', function() {
					submitContainer.fadeIn('fast', function() {
					});	
				});
			});

			if (this.useWizard) {
				console.log('using wizard');
				this.$el.find("li.step-label:first").addClass("active");
				this.$el.find("div.step-pane:first").addClass("active");
				this.$el.wizard();
			} else {
				console.log('not using wizard');
				
				this.$el.find("li.step-label").addClass("active");
				this.$el.find("div.step-pane").addClass("active");
				

			}
		}
	});
	return Form;
});
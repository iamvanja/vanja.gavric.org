define([
	"spa/templates",
	"spa/components/TabsHeadersItem"
	],
	function(t, TabsHeadersItem){
		var View = Backbone.Marionette.CollectionView.extend({
			className: "nav nav-tabs",
			tagName: "ul",
			initialize: function(){
				this.delegate = this.options.delegate;
			},
			itemViewOptions: function(){
				return {
					delegate: this.delegate
				};
			},
			itemView: TabsHeadersItem
		});
		return View;
	});
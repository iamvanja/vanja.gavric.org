define([
	"spa/templates"
	],
	function(t){
	var ListCellItemText = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return window.JST["components/listCellItemText.html"](serialized);
		},
		tagName: "span"
	});
	return ListCellItemText;
});
define([
	"spa/templates",
	"spa/components/ListContentItem"
	],
	function(t, ListContentItem){
	var ListContent = Backbone.Marionette.CollectionView.extend({
		itemView: ListContentItem,
		itemViewOptions: function(){
			return {
				fieldTypes: this.fieldTypes
			};
		},
		// className: "listTable",
		tagName: "tbody",
		initialize: function() {
			this.fieldTypes = this.options.fieldTypes;
		}
	});
	return ListContent;
});
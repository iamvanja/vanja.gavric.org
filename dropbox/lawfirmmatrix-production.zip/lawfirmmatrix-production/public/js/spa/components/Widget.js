define([
	"spa/templates"
	], 
	function(){
	var Widget = Backbone.Marionette.Layout.extend({
		initialize: function(){
			this.collection = this.options.collection;
		},
		template: function(serialized){
			return window.JST["components/widget.html"](serialized);
		},
		regions:{
			main: "div.widget-main"
		}
	});
	return Widget;
});
define([
	"spa/templates",
	"spa/components/ListHeader"
	],
	function(t, ListHeader){
	var ListHeaders = Backbone.Marionette.CompositeView.extend({
		itemView: ListHeader,
		tagName:"thead",
		className: "listTable123",
		// itemViewContainer: ".tr",
		initialize: function() {

		},
		template: function() {
			// return "<div class=\"tr\"></div>";
		}
	});
	return ListHeaders;
});
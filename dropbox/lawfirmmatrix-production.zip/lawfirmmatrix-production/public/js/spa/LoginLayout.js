define([
	"spa/templates"
	],
	function(t){
	var LoginLayout = Backbone.Marionette.Layout.extend({
		initialize: function(){
			var that = this;
			this.sm = this.options.sessionManager;
			this.sm.on("loginFail", function(){
				that.showErrors();
			});
		},
		template: function(){
			return window.JST["loginLayout.html"];
		},
		ui: {
			errors: "div.validation-summary-errors",
			username: "input#UserName",
			password: "input#Password" 
		},
		events: {
			"click button.btn-login": "performLogin",
			"keydown input#Password": "pushEnter",
			"keydown input#UserName": "turnEnterToTab"
		},
		performLogin: function(){
			this.hideErrors();
			this.sm.login(this.ui.username.val(), this.ui.password.val());
		},
		hideErrors: function(){
			this.ui.errors.addClass("hide");
		},
		showErrors: function(){
			this.ui.errors.removeClass("hide");
		},
		pushEnter: function(e){
			if(e.keyCode === 13){
				this.performLogin();
			}
		},
		turnEnterToTab: function(e){
			if(e.keyCode === 13){
				this.ui.password.focus();
			}
		}
	});
	return LoginLayout;
});
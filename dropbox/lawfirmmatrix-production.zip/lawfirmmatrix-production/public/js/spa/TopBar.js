define([
	"spa/templates"
	], 
	function(){
	var TopBar = Backbone.Marionette.ItemView.extend({
		template: function(){
			return window.JST["topBar.html"];
		}
	});
	return TopBar;
});
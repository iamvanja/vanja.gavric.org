define([
	"spa/templates",
	"spa/MenuOptionItem"
	], 
	function(t, MenuOptionItem){
	var MenuOption = Backbone.Marionette.CompositeView.extend({
		tagName: "li",
		className: ".js-menuOption",
		initialize: function(){
			this.collection = new Backbone.Collection(this.model.get("options"));
			this.delegate = this.options.delegate;
			this.parent = this.options.parent;
			this.items = [];
			this.parent.opts.push(this);
		},
		itemView: MenuOptionItem,
		itemViewContainer: ".js-submenu",
		itemViewOptions: function(){
			return {
				parent: this,
				delegate: this.delegate
			};
		},
		template: function(serialized){
			return window.JST["menuOption.html"](serialized);
		},
		select: function(){
			this.parent.deselectAllOptions();
			this.$el.addClass("active");
		},
		deselect: function(){
			this.$el.removeClass("active");
			this.deselectAllItems();
		},
		deselectAllItems: function(){
			var arr = this.items,
				l = arr.length,
				i;
			for(i = 0; i < l; i += 1){
				arr[i].deselect();
			}
		}
	});
	return MenuOption;
});
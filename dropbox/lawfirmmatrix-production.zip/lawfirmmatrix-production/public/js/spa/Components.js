define([
	"spa/components/Form",
	"spa/components/Widget",
	"spa/components/Tabs",
	"spa/components/List"
	], 
	function(Form, Widget, Tabs, List){
	
	return {
		Form: Form,
		Widget: Widget,
		Tabs: Tabs,
		List: List
	};
});
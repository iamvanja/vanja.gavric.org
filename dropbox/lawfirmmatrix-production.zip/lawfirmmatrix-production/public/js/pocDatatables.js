function guidGenerator() {
        var S4 = function() {
                return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

Row = Backbone.Model.extend({
        id: null,
        title: null,
        price: 0
});

var Rows = Backbone.Collection.extend({
        initialize: function(models, options) {
                this.bind("add", options.view.addRow);
        }
});

AppView = Backbone.View.extend({
        el: $("#application"),
        initialize: function() {
                this.rowsdata = new Rows(null, {
                        view: this
                });
        },
        events: {
                "click #addRowButton": "addGift"
        },
        updateRow: function(id, column, value) {
                var myGift = this.rowsdata.get(id);
                myGift.set(column, value);
                $("#displayModel").text(JSON.stringify(appview.getRowsData()));
        },
        addOneRow: function(mytitle, myprice) {
                var gift_model = new Row({
                        title: mytitle,
                        price: myprice,
                        id: guidGenerator()
                });

                this.rowsdata.add(gift_model);

                $("#displayModel").text(JSON.stringify(appview.getRowsData()));
        },
        addGift: function() {
                var gift_model = new Row({
                        title: $("#newTitle").val(),
                        price: $("#newPrice").val(),
                        id: guidGenerator()
                });

                this.rowsdata.add(gift_model);

                $("#displayModel").text(JSON.stringify(appview.getRowsData()));
        },

        addRow: function(model) {
                $('#exampletable').dataTable().fnAddData(model.toJSON());
        },
        getRowsData: function() {
                return this.rowsdata;
        }

});

var appview = new AppView;

$(document).ready(function() {
        console.log('init...');
        var test = appview.getRowsData();

        console.log('data: ');
        console.log(test);
        console.log(test.toJSON());

        oTable = $('#exampletable').dataTable({
                aaData: test.toJSON(),
                aoColumns: [
                        {
                                sTitle: 'Id',
                                mDataProp: 'id',
                                bSearchable: false,
                                bVisible:    false
                        },
                        {
                                sTitle: 'Title',
                                mDataProp: 'title'
                        },
                        {
                                sTitle: 'Price',
                                mDataProp: 'price'
                        }
                ]
                // "fnDrawCallback": function() {
                //         $('#exampletable tbody td').editable(
                //                 function(value, settings) {
                //                         var aPos = oTable.fnGetPosition(this);
                //                         var aData = oTable.fnGetData(aPos[0]);

                //                         appview.updateRow(aData.id, GetAttributeName(this.cellIndex), value);
                //                         return (value);
                //                 },
                //                 {
                //                         "height": "14px",
                //                         submit: "OK",
                //                         id: "id"
                //                 }
                //         );
                // }
        });

        appview.addOneRow("likewoah", 3.33);
        // appview.addOneRow("likewoah1", 3.43);
        // appview.addOneRow("test", 311.33);
        // appview.addOneRow("asdasd", 324.33);
        // appview.addOneRow("zxc", 99.99);
        // appview.addOneRow("123464575676", 3.33);
});


function GetAttributeName(index) {
        switch (index) {
                case 0:
                return "title";
                case 1:
                return "price";
                default:
        }
}

var oTable;
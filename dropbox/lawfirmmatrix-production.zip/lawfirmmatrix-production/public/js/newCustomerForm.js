var ListItemView = Backbone.Marionette.ItemView.extend({
		template: function(serialized){
			return _.template("<li><%=label%></li>",serialized);
		}
	}),
	ListViewEmpty = Backbone.Marionette.ItemView.extend({
		template: function(){
			return "<li>No Items</li>";
		}
	}),
	ListView = Backbone.Marionette.CompositeView.extend({
		template: function(){
			return "<ul class=\"items\"></ul>"
		},
		itemViewContainer: "ul.items",
		itemView: ListItemView,
		emptyView: ListViewEmpty,

	}),

	FormField = Backbone.Marionette.CompositeView.extend({
		template: function(serialized){
			return _.template($("#FormFieldTemplate").html(), serialized);
		},
		ui: {
			input: "input",
			btnEdit: "div.actions>div.edit",
			btnConfirm: "div.actions>div.confirm",
			btnCancel: "div.actions>div.cancel",
			btnUndo: "div.actions>div.undo",
			btnSaving: "div.actions>div.saving",
			valContainer: ".formValue"
			// btnAdd: "div.actions>div.add",
		},
		events: {
			"click div.actions > div.edit": "startEditing",
			"click div.actions > div.cancel": "cancelEditing",
			"click div.actions > div.undo": "undoChanges",
			"keydown input": "keystroke",
			"focus input": "inputFocused",
			"blur input": "inputBlur",
			"mouseenter .formValue": "fieldMouseEnter",
			"mouseleave .formValue": "fieldMouseLeave",
		},
		undoChanges: function(e) {
			var prevVal = this.model.get("prevvalue");
			//console.log('undo => ' + prevVal);
			this.model.set("value", prevVal);
			this.ui.btnUndo.hide();
			this.cancelEditing();
		},
		fieldMouseEnter: function(e) {
			this.ui.valContainer.addClass('valHover');
		},
		fieldMouseLeave: function(e) {
			this.ui.valContainer.removeClass('valHover');
		},
		startEditing: function(){
			this.ui.btnEdit.hide();
			this.ui.btnCancel.show();
			this.ui.btnConfirm.show();
		},
		cancelEditing: function() {
			this.ui.btnEdit.show();
			this.ui.btnCancel.hide();
			this.ui.btnConfirm.hide();

			//console.log('cancel: set input to: ' + this.model.get("value"));
			this.ui.input.val(this.model.get("value"));
			this.ui.input.attr('nosave', '1');
			this.ui.input.blur();
		},
		inputBlur: function(e) {

			// 1. remove visual style of focus
			var self = this;
			this.ui.valContainer.removeClass('valFocused');
			this.ui.valContainer.removeClass('valHover');

			// 2. Delay (give time to any button event to abort the blur event)
			e.preventDefault(e);
			setTimeout(function() {
				if (self.ui.input.attr('nosave') == '1') {
					console.log('not saving :)');
					self.ui.input.removeAttr('nosave');
					return;
				}

				//console.log('saving...');
				self.save(false, function() {
					return true;
				});
			}, 300);
			
		},
		inputFocused: function(e) {
			this.startEditing();
			this.ui.input.removeAttr('nosave');
			this.ui.valContainer.addClass('valFocused');
			this.ui.input.select();
		},
		keystroke: function(e) {
			var self = this;
			var keyCode = e.keyCode || e.which; 

			/*
			if (keyCode == 9) { // tab
				this.save(false, function() {
					console.log('tab!');
					// todo: activate next Edit button (.next() ?)
				});
			} 
			*/

			if (keyCode == 13) { // enter
				self.ui.input.blur();
			} 

			if (keyCode == 27) { // esc
				this.cancelEditing();
			} 
			//console.log('keystroke:', keyCode);
		},
		save: function(blurAfter, cb) {
			var that 	= this;
			var prevVal = this.model.get("prevvalue") || this.model.get("value");
			var newVal 	= this.ui.input.val();

			//console.log('prev=' + prevVal);
			//console.log('new=' + newVal);

			this.model.set("prevvalue", prevVal);
			this.model.set("value", newVal);
			// this.ui.label.html(this.model.get("value")).show();
			this.ui.btnCancel.hide();
			this.ui.btnConfirm.hide();
			this.ui.btnSaving.show();
			if (blurAfter) this.ui.input.blur();
			setTimeout(function(){
				that.ui.btnSaving.hide();
				that.ui.btnEdit.show();

				if (newVal != prevVal) {
					that.ui.btnUndo.show();
				}

				return cb();
			}, 200);
		}


	}),
	FormSection = Backbone.Marionette.CompositeView.extend({
		initialize: function(){
			this.collection = new Backbone.Collection(this.model.get("fields"))
		},
		template: function(serialized){
			return _.template($("#FormSectionTemplate").html(),serialized);
		},
		itemViewContainer: "form",
		itemView: FormField
	}),
	Form = Backbone.Marionette.CompositeView.extend({
		className: "wizard",
		initialize: function(){
			this.collection = new Backbone.Collection(this.model.get("steps"));
		},
		template: function(serialized){
			return _.template($("#FormTemplate").html(), serialized);
		},
		itemViewContainer: "#step-container",
		itemView: FormSection,
		onShow: function(){
			this.$el.find("li.step-label:first").addClass("active");
			this.$el.find("div.step-pane:first").addClass("active");
			this.$el.wizard();
		}
	}),
	Widget = Backbone.Marionette.Layout.extend({
		initialize: function(){
			this.collection = this.options.collection;
		},
		template: function(serialized){
			return _.template($("#WidgetTemplate").html(), serialized);
		},
		regions:{
			main: "div.widget-main"
		}
	}),
	App = Backbone.Marionette.Application.extend({
		init: function(){
			var widget = new Widget({
					model: new Backbone.Model({
						title: "New Customer Form"
					})
				});

			this.mainRegion.show(widget);
			widget.main.show(new Form({
				model: new Backbone.Model({
					steps: [
						{
							name: 1,
							title: "Customer Details",
							fields: [
								{label: "Customer Status", value: "", tabindex: 1},
								{label: "Customer Type", value: "", tabindex: 2},
								{label: "Contact", value: "", tabindex: 3}
							]
						},
						{
							name: 2,
							title: "Account Details",
							fields: [
								{label: "Primary Account Owner", value: "", tabindex: 1},
								{label: "Account Owner", value: "", tabindex: 2},
								{label: "Referral", value: "", tabindex: 3},
							]
						}
					]
				})
			}));

			window.app = this;
		}
	}), 

	app = new App();

app.addRegions({
	"mainRegion": "#application"
});

app.addInitializer(function(){
	this.init();
});

app.start();

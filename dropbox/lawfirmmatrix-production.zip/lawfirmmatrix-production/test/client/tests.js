requirejs.config({
  deps: ["mocha"],
  urlArgs: "v="+(new Date()).getTime(),
  paths: {
  	"spa": "../../public/js/spa"
  },

  shim: {
  }
});
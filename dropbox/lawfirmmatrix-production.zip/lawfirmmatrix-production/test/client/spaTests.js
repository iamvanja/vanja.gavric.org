define([
	"tests/spa/Hello",
	"tests/spa/FormField",
	"tests/spa/List",
	"tests/spa/SessionManager"
	],
	function(Hello){
		return {};
	}
);
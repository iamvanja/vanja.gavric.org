define([
	"spa/components/FormField",
	"spa/components/FormFieldText",
	"spa/components/FormFieldMultiline"
	],
	function(FormField, FormFieldText, FormFieldMultiline){
		describe("FormField", function(){
			it("should initialize controlView with different classes", function() {
				var formField = new FormField({
					model: new Backbone.Model({
						type: "text"
					})
				});

				expect(formField.controlView).to.be.an.instanceof(FormFieldText);
				expect(formField.controlView).not.to.be.an.instanceof(FormFieldMultiline);
			});
		});
	}
);
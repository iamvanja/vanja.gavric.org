define([
	"spa/Hello"
	],
	function(Hello){
		describe("Spa Hello view", function(){
			it("should return the model name", function(){
				var hello = new Hello({
					model: new Backbone.Model({
						name: "testName"
					})
				});

				expect(hello.name()).to.equal("testName");
			});
		});
	}
);
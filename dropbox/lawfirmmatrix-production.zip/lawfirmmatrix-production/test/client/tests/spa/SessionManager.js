define([
	"spa/SessionManager"
	],
	function(SessionManager){
		describe("Session Manager Component", function(){
			it("should parse a login success response and save the state", function() {
				var sm = new SessionManager();

				sm.parse({
					response: "success",
					user: {
						fullname: "Yossi Halberstam",
						userId: "01",
						profilePhoto: "img/user.jpg"
					},
					company: {
						name: "LawFirm Matrix",
						logo: "img/KLF-logo.png"
					},
					session:{
						tabs: {
							current: 0,
							opened: [
								{
									title: "Client List",
									active: true,
									type: "list",
									api: "/api/scheme/clients"
								},
								{
									title: "New Client",
									active: false,
									type: "newEntity",
									api: "/api/scheme/newClient"
								}
							]
						}
					}
				});
				expect(sm.loggedIn).to.equal(true);
			});

			it("should parse a login fail response and save the state", function() {
				var sm = new SessionManager();

				sm.parse({
					response: "fail",
					sessionId: ""
				});
				expect(sm.loggedIn).to.equal(false);
			});
		});
	}
);
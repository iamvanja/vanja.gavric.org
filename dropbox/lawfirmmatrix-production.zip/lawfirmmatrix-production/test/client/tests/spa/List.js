define([
	"spa/components/List"
	],
	function(List){
		describe("ListComponent", function(){
			it("should initialize a list", function() {
				var list = new List({
					schema: {
						fields: ["field1", "field2", "field3"]
					},
					data: [
						{ field1: "value1", field2: "value2", field3: "value3" },
						{ field1: "value1", field2: "value2", field3: "value3" },
						{ field1: "value1", field2: "value2", field3: "value3" }
					]
				});

				expect(list).to.not.be.undefined;
			});
		});
	}
);